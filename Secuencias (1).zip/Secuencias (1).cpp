#include <iostream>
#include "Sec.h"
using namespace std;

void mostrarMenu() {
    cout << "Menu" << endl;
    cout << "1. Generar Secuencia" << endl;
    cout << "2. Salir" << endl;
    cout << "Elija una opcion: ";
}

int main() {
    Secuencia secuencia;
    int opcion;
    int cantidad;

    do {
        mostrarMenu();
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Ingrese la cantidad de elementos a generar: ";
            cin >> cantidad;
            secuencia.setN(cantidad);
            secuencia.generarSecuencia();
            break;
        case 2:
            cout << "Saliendo..." << endl;
            break;
        default:
            cout << "Opcion no valida. Intente de nuevo." << endl;
        }
    } while (opcion != 2);

    return 0;
}
