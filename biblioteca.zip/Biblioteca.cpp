#include <iostream>
#include <string>
#include "Biblioteca.h"
using namespace std;

Biblioteca::Biblioteca() {
    titulo = "";
    autor = "";
    anio = 0;
}

Biblioteca::Biblioteca(string tit, string aut, int an) {
    titulo = tit;
    autor = aut;
    anio = an;
}

void Biblioteca::setLibro(string tit, string aut, int an) {
    titulo = tit;
    autor = aut;
    anio = an;
}

string Biblioteca::getTitulo() {
    return titulo;
}

string Biblioteca::getAutor() {
    return autor;
}

int Biblioteca::getAnio() {
    return anio;
}


void Biblioteca::guardarArchivo(ofstream& fsalida) {
    fsalida.write(reinterpret_cast<char*>(&titulo), sizeof(titulo));
    fsalida.write(reinterpret_cast<char*>(&autor), sizeof(autor));
    fsalida.write(reinterpret_cast<char*>(&anio), sizeof(anio));
}

bool Biblioteca::leerArchivo(ifstream& fentrada) {
    size_t tamTitulo, tamAutor;

    if (fentrada.read(reinterpret_cast<char*>(&tamTitulo), sizeof(tamTitulo))) {
        char* bufferTitulo = new char[tamTitulo + 1];
        fentrada.read(bufferTitulo, tamTitulo);
        bufferTitulo[tamTitulo] = '\0';
        titulo = bufferTitulo;
        delete[] bufferTitulo;

        fentrada.read(reinterpret_cast<char*>(&tamAutor), sizeof(tamAutor));
        char* bufferAutor = new char[tamAutor + 1];
        fentrada.read(bufferAutor, tamAutor);
        bufferAutor[tamAutor] = '\0';
        autor = bufferAutor;
        delete[] bufferAutor;

        fentrada.read(reinterpret_cast<char*>(&anio), sizeof(anio));
        return true;
    }
    return false;
}

bool Biblioteca::leerArchivo(ifstream& fentrada) {
    bool k = false;
    if (fentrada.is_open()) {
        fentrada.read(reinterpret_cast<char*>(&titulo), sizeof(titulo));
        if (!fentrada.eof()) {
            fentrada.read(reinterpret_cast<char*>(&autor), sizeof(autor));
            fentrada.read(reinterpret_cast<char*>(&anio), sizeof(anio));
            k = true;
        }
        else
            cout << endl << "Registro no existe";
    }
    else
        cout << endl << "Archivo no existe";
    return k;
}

