#include "BibliotecaManager.h"

BibliotecaManager::BibliotecaManager(string nomArch) {
    nomArchivo = nomArch;
    cabeza = nullptr;
}

BibliotecaManager::~BibliotecaManager() {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        Nodo* siguiente = actual->siguiente;
        delete actual;
        actual = siguiente;
    }
}

void BibliotecaManager::agregarLibro() {
    ofstream fsalida(nomArchivo, ios::app | ios::binary);
    if (!fsalida) {
        cerr << "Error al abrir el archivo para escribir" << endl;
        return;
    }
    Biblioteca libro;
    string titulo, autor;
    int anio;
    cout << "Introducir los siguientes datos del libro --->>> :" << endl;
    cout << "Titulo : ";
    cin.ignore();
    getline(cin, titulo);
    cout << "Autor : ";
    getline(cin, autor);
    cout << "Anio : ";
    cin >> anio;
    libro.setLibro(titulo, autor, anio);
    libro.guardarArchivo(fsalida);
    fsalida.close();
}

void BibliotecaManager::leerLibros() {
    ifstream fentrada(nomArchivo, ios::in | ios::binary);
    if (!fentrada) {
        cerr << "Error al abrir el archivo para leer" << endl;
        return;
    }
    Nodo* ultimo = nullptr;
    while (true) {
        Biblioteca libro;
        if (!libro.leerArchivo(fentrada)) {
            break;
        }
        Nodo* nuevo = new Nodo;
        nuevo->libro = libro;
        nuevo->siguiente = nullptr;
        if (ultimo == nullptr) {
            cabeza = nuevo;
        }
        else {
            ultimo->siguiente = nuevo;
        }
        ultimo = nuevo;
    }
    fentrada.close();
}

void BibliotecaManager::mostrarLibros() {
    leerLibros();
    cout << "Los libros en la biblioteca son --->>> :" << endl;
    Nodo* actual = cabeza;
    int index = 1;
    while (actual != nullptr) {
        cout << index << ".- Titulo: " << actual->libro.getTitulo()
            << ", Autor: " << actual->libro.getAutor()
            << ", Anio: " << actual->libro.getAnio() << endl;
        actual = actual->siguiente;
        index++;
    }
}
