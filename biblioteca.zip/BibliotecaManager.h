#include <iostream>
#include <fstream>
#include "Biblioteca.h"

using namespace std;

struct Nodo {
    Biblioteca libro;
    Nodo* siguiente;
};

class BibliotecaManager {
private:
    string nomArchivo;
    Nodo* cabeza;

public:
    BibliotecaManager(string nomArch);
    ~BibliotecaManager();

    void agregarLibro();
    void mostrarLibros();
    void leerLibros();
};
